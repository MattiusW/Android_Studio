package com.mw.pierwsza_aplikacja;

import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    CarExpert expert = new CarExpert();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void onClickFindCar(View view) {
        TextView viewCars = (TextView) findViewById(R.id.view_models);
        Spinner spinner = (Spinner) this.<View>findViewById(R.id.car_category);
        String carType = String.valueOf(spinner.getSelectedItem());
        List<String> brandList = expert.getCars(carType);
        StringBuilder brandsFormatted = new StringBuilder();

        for (String brand : brandList) {
            brandsFormatted.append(brand).append('\n');
        }

        viewCars.setText(brandsFormatted);

    }
}
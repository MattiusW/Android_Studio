package com.mw.pierwsza_aplikacja;

import java.util.ArrayList;
import java.util.List;

public class CarExpert {

    List<String> getCars(String category) {

        List<String> brands = new ArrayList<>();

        if (category.equals("sportowe")) {
            brands.add("Ferrari");
            brands.add("Lamborgini");
            brands.add("Viper");
        }

        if (category.equals("kompaktowe")) {
            brands.add("Golf");
            brands.add("Opel");
            brands.add("Hiundai");
        }

        if (category.equals("limuzyny")) {
            brands.add("Maybach");
            brands.add("Audi");
            brands.add("Mercedenz-Benz");
        }

        return brands;
    }
}
